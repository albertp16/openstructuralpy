from setuptools import setup, find_packages

setup(
    name='openstructuralpy',
    version='0.1',
    packages=find_packages(),
    install_requires=[
        # Add required dependencies here, e.g., 'numpy', 'pandas', etc.
    ],
)