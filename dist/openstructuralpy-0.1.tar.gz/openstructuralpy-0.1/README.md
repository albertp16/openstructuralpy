# OpenStructuralPy

OpenStructuralPy is a Python library for structural engineering calculations.

## Installation
```sh
pip install openstructuralpy
